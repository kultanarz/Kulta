sudo apt install wget
sudo yum install wget
rm -rf Kenos.py
rm -rf installation.sh
wget https://raw.githubusercontent.com/d3fe4ted/KenosV2/main/Kenos.py
wget https://raw.githubusercontent.com/d3fe4ted/KenosV2/main/installation.sh
bash installation.sh